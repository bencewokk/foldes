<footer id="site-footer">
    <div class="footer-content">
        <p class="school-name">Földes Ferenc Gimnázium</p>
        <div class="footer-info">
            <p>&copy; <?php echo date('Y'); ?> Minden jog fenntartva</p>
            <p class="creator">Created by Balabás Bence</p>
        </div>
    </div>
</footer>