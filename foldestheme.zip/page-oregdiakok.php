<?php
/* Template Name: Öregdiákok */
get_header(); ?>

<div class="content">
    <h1>Öregdiákok</h1>
    <p>Content for the Öregdiákok page goes here...</p>
</div>

<?php get_footer(); ?>